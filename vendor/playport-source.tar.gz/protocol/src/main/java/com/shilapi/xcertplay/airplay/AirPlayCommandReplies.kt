package com.shilapi.xcertplay.airplay

import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap

data class AirPlayCommandReply(val status: Int, val errorCode: Long? = null, val validBody: Boolean = true) {
    // Accepted is a command acknowledgement, not foreground-app confirmation.
    val accepted: Boolean get() = status in 200..299 && validBody && (errorCode == null || errorCode == 0L)
}

internal class AirPlayCommandReplies {
    private val pending = ConcurrentHashMap<Int, CompletableFuture<AirPlayCommandReply>>()
    fun register(sequence: Int) = CompletableFuture<AirPlayCommandReply>().also { pending[sequence] = it }
    fun remove(sequence: Int) { pending.remove(sequence) }

    fun handle(message: RtspMessage.Request) {
        val sequence = message.headers["cseq"]?.toIntOrNull() ?: return
        val status = message.path.toIntOrNull() ?: return
        val future = pending.remove(sequence) ?: return
        var validBody = true
        val body = if (message.body.isEmpty()) emptyMap<Any?, Any?>() else {
            runCatching { BplistCodec.decode(message.body) as? Map<*, *> }.getOrNull().also {
                if (it == null) validBody = false
            }.orEmpty()
        }
        val error = (body["status"] as? Number)?.toLong()?.takeIf { it != 0L }
            ?: (body["error"] as? Number)?.toLong()
            ?: ((body["error"] as? Map<*, *>)?.get("code") as? Number)?.toLong()
        future.complete(AirPlayCommandReply(status, error, validBody))
    }

    fun close() {
        pending.values.forEach { it.completeExceptionally(java.io.IOException("CarPlay session ended")) }
        pending.clear()
    }
}

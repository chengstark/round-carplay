package com.shilapi.xcertplay.airplay

import org.junit.Assert.*
import org.junit.Test

class AirPlayCommandRepliesTest {
    private fun response(sequence: Int, status: Int = 200, body: ByteArray = byteArrayOf()) =
        RtspMessage.Request("RTSP/1.0", status.toString(), "OK", mapOf("cseq" to sequence.toString()), body)

    @Test fun matchesRepliesBySequenceWhenTheyArriveOutOfOrder() {
        val replies = AirPlayCommandReplies()
        val first = replies.register(1); val second = replies.register(2)
        replies.handle(response(99))
        replies.handle(response(2))
        assertFalse(first.isDone); assertTrue(second.join().accepted)
        replies.handle(response(1, 404))
        assertFalse(first.join().accepted)
    }

    @Test fun rejectsApplicationErrorsAndMalformedBodiesEvenWithHttpSuccess() {
        val replies = AirPlayCommandReplies()
        for ((sequence, body) in listOf(
            1 to BplistCodec.encode(mapOf("status" to -50)),
            2 to BplistCodec.encode(mapOf("error" to mapOf("code" to 42))),
            3 to byteArrayOf(1, 2, 3),
        )) {
            val future = replies.register(sequence)
            replies.handle(response(sequence, body = body))
            assertFalse(future.join().accepted)
        }
        val success = replies.register(4)
        replies.handle(response(4, body = BplistCodec.encode(mapOf("status" to 0))))
        assertTrue(success.join().accepted)
    }

    @Test fun cancelledRequestsIgnoreLateRepliesAndSessionCloseReleasesWaiters() {
        val replies = AirPlayCommandReplies()
        val timedOut = replies.register(1)
        replies.remove(1); replies.handle(response(1))
        assertFalse(timedOut.isDone)
        val pending = replies.register(2)
        replies.close()
        assertTrue(pending.isCompletedExceptionally)
    }
}

/*
 * PlayPort Linux Bluetooth bridge.
 *
 * Uses BlueZ to locate the iAP2 RFCOMM service exported by a paired iPhone,
 * opens that channel, and forwards raw bytes between RFCOMM and stdin/stdout.
 */

#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>
#include <bluetooth/rfcomm.h>
#include <bluetooth/sdp.h>
#include <bluetooth/sdp_lib.h>
#include <errno.h>
#include <poll.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static const uint8_t IAP2_UUID[16] = {
    0x00, 0x00, 0x00, 0x00, 0xde, 0xca, 0xfa, 0xde,
    0xde, 0xca, 0xde, 0xaf, 0xde, 0xca, 0xca, 0xfe,
};

static void fail(const char *message) {
    fprintf(stderr, "bt-bridge: %s\n", message);
    exit(1);
}

static void fail_errno(const char *operation) {
    fprintf(stderr, "bt-bridge: %s: %s\n", operation, strerror(errno));
    exit(1);
}

static void print_address(void) {
    int device_id = hci_get_route(NULL);
    bdaddr_t address;
    char text[19];
    if (device_id < 0 || hci_devba(device_id, &address) < 0) {
        fail_errno("local Bluetooth address unavailable");
    }
    ba2str(&address, text);
    puts(text);
}

static void list_paired(void) {
    FILE *devices = popen("bluetoothctl devices Paired", "r");
    char line[512];
    if (devices == NULL) fail_errno("could not query paired devices");
    while (fgets(line, sizeof(line), devices) != NULL) {
        const char *prefix = "Device ";
        char *start = line;
        if (strncmp(start, prefix, strlen(prefix)) == 0) start += strlen(prefix);
        fputs(start, stdout);
    }
    if (pclose(devices) == -1) fail_errno("paired-device query failed");
}

static int iap2_rfcomm_channel(const bdaddr_t *remote) {
    bdaddr_t local = {{0, 0, 0, 0, 0, 0}};
    sdp_session_t *session = sdp_connect(&local, remote, SDP_RETRY_IF_BUSY);
    sdp_list_t *search = NULL;
    sdp_list_t *attributes = NULL;
    sdp_list_t *records = NULL;
    uuid_t uuid;
    uint32_t range = 0x0000ffff;
    int channel = -1;

    if (session == NULL) return -1;
    sdp_uuid128_create(&uuid, IAP2_UUID);
    search = sdp_list_append(NULL, &uuid);
    attributes = sdp_list_append(NULL, &range);
    if (sdp_service_search_attr_req(session, search, SDP_ATTR_REQ_RANGE, attributes, &records) == 0) {
        for (sdp_list_t *item = records; item != NULL && channel < 0; item = item->next) {
            sdp_record_t *record = item->data;
            sdp_list_t *protocols = NULL;
            if (sdp_get_access_protos(record, &protocols) == 0) {
                channel = sdp_get_proto_port(protocols, RFCOMM_UUID);
                sdp_list_foreach(protocols, (sdp_list_func_t)sdp_list_free, NULL);
                sdp_list_free(protocols, NULL);
            }
        }
    }
    sdp_list_free(search, NULL);
    sdp_list_free(attributes, NULL);
    sdp_list_free(records, (sdp_free_func_t)sdp_record_free);
    sdp_close(session);
    return channel;
}

static void write_all(int fd, const uint8_t *bytes, size_t length) {
    while (length > 0) {
        ssize_t written = write(fd, bytes, length);
        if (written < 0) {
            if (errno == EINTR) continue;
            fail_errno("write failed");
        }
        bytes += written;
        length -= (size_t)written;
    }
}

static void bridge(const char *address_text) {
    bdaddr_t remote;
    struct sockaddr_rc destination = {0};
    struct pollfd descriptors[2];
    uint8_t buffer[4096];
    int channel;
    int socket_fd;

    if (str2ba(address_text, &remote) != 0) fail("invalid Bluetooth address");
    channel = iap2_rfcomm_channel(&remote);
    if (channel <= 0) {
        fail("the device does not expose the iAP2 service; make sure it is paired, awake, and in range");
    }

    socket_fd = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);
    if (socket_fd < 0) fail_errno("could not create RFCOMM socket");
    destination.rc_family = AF_BLUETOOTH;
    destination.rc_bdaddr = remote;
    destination.rc_channel = (uint8_t)channel;
    fprintf(stderr, "bt-bridge: opening RFCOMM channel %d to %s\n", channel, address_text);
    if (connect(socket_fd, (struct sockaddr *)&destination, sizeof(destination)) < 0) {
        fail_errno("RFCOMM connect failed");
    }
    fprintf(stderr, "bt-bridge: RFCOMM channel open\n");

    descriptors[0] = (struct pollfd){.fd = STDIN_FILENO, .events = POLLIN};
    descriptors[1] = (struct pollfd){.fd = socket_fd, .events = POLLIN};
    for (;;) {
        if (poll(descriptors, 2, -1) < 0) {
            if (errno == EINTR) continue;
            fail_errno("poll failed");
        }
        if (descriptors[0].revents & (POLLIN | POLLHUP)) {
            ssize_t count = read(STDIN_FILENO, buffer, sizeof(buffer));
            if (count <= 0) break;
            write_all(socket_fd, buffer, (size_t)count);
        }
        if (descriptors[1].revents & (POLLIN | POLLHUP | POLLERR)) {
            ssize_t count = read(socket_fd, buffer, sizeof(buffer));
            if (count <= 0) break;
            write_all(STDOUT_FILENO, buffer, (size_t)count);
        }
    }
    close(socket_fd);
    fprintf(stderr, "bt-bridge: RFCOMM channel closed\n");
}

static void usage(const char *program) {
    fprintf(stderr,
            "Usage: %s --print-address | --list | --address AA:BB:CC:DD:EE:FF\n",
            program);
    exit(2);
}

int main(int argc, char **argv) {
    signal(SIGPIPE, SIG_IGN);
    if (argc == 2 && strcmp(argv[1], "--print-address") == 0) {
        print_address();
        return 0;
    }
    if (argc == 2 && strcmp(argv[1], "--list") == 0) {
        list_paired();
        return 0;
    }
    if (argc == 3 && strcmp(argv[1], "--address") == 0) {
        bridge(argv[2]);
        return 0;
    }
    usage(argv[0]);
}

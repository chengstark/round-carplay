#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cc -O2 -Wall -Wextra -Werror \
  "$SCRIPT_DIR/main.c" \
  -lbluetooth \
  -o "$SCRIPT_DIR/bt-bridge"
echo "Built $SCRIPT_DIR/bt-bridge"

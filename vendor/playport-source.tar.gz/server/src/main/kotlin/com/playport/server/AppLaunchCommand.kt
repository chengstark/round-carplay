package com.playport.server

import com.shilapi.xcertplay.airplay.AirPlayInfoPlist

/** A car-initiated UI request explicitly targets the main CarPlay display. */
internal fun appLaunchCommand(app: String): Map<String, Any?>? {
    val url = when (app) {
        "youtube-music" -> "youtubemusic://"
        "phone" -> "mobilephone://"
        else -> return null
    }
    return mapOf("type" to "showUI", "params" to mapOf("uuid" to AirPlayInfoPlist.MAIN_UUID, "url" to url))
}

package com.playport.server

/** A lingering RFCOMM bootstrap must not suppress recovery after Wi-Fi drops. */
internal fun shouldRetryWireless(
    bootstrapRunning: Boolean,
    elapsedMillis: Long,
    sessionEndedSinceBootstrap: Boolean,
): Boolean {
    if (elapsedMillis < 20_000L) return false
    // Allow a fresh handshake time to complete, but bound a stuck initial setup.
    return !bootstrapRunning || sessionEndedSinceBootstrap || elapsedMillis >= 90_000L
}

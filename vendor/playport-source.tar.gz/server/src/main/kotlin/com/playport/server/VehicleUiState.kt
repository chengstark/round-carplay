package com.playport.server

import com.shilapi.xcertplay.iap2.message.Iap2NowPlayingAccumulator
import com.shilapi.xcertplay.iap2.message.Iap2Messages
import com.shilapi.xcertplay.iap2.wire.Iap2Frame
import kotlinx.serialization.Serializable

@Serializable
data class NowPlayingViewState(
    val title: String? = null,
    val artist: String? = null,
    val album: String? = null,
    val appName: String? = null,
    val durationMillis: Long? = null,
    val elapsedMillis: Long = 0,
    val playback: String = "stopped",
    val artworkTransferId: Int? = null,
    val receivedAtEpochMillis: Long = 0,
)

@Serializable
data class ManeuverViewState(
    val index: Int? = null,
    val description: String? = null,
    val roadName: String? = null,
    val type: Int? = null,
    val distanceMeters: Long? = null,
    val distanceText: String? = null,
    val distanceUnit: Int? = null,
)

@Serializable
data class NavigationViewState(
    val active: Boolean = false,
    val maneuverUpdate: Boolean = false,
    val routeState: Int = 0,
    val currentRoad: String? = null,
    val destination: String? = null,
    val estimatedArrival: Long? = null,
    val timeRemainingSeconds: Long? = null,
    val distanceRemainingMeters: Long? = null,
    val distanceRemainingText: String? = null,
    val distanceRemainingUnit: Int? = null,
    val distanceToManeuverMeters: Long? = null,
    val distanceToManeuverText: String? = null,
    val distanceToManeuverUnit: Int? = null,
    val sourceName: String? = null,
    val maneuver: ManeuverViewState? = null,
    val updateSequence: Long = 0,
)

@Serializable
data class PhoneViewState(
    val active: Boolean = false,
    val status: String = "idle",
    val updateSequence: Long = 0,
)

@Serializable
data class VehicleUiSnapshot(
    val nowPlaying: NowPlayingViewState = NowPlayingViewState(),
    val navigation: NavigationViewState = NavigationViewState(),
    val phone: PhoneViewState = PhoneViewState(),
)

/** Turns incremental iAP2 metadata into a browser-friendly, immutable vehicle UI snapshot. */
class VehicleUiState(private val publish: (VehicleUiSnapshot) -> Unit) {
    private val nowPlaying = Iap2NowPlayingAccumulator()
    private val maneuvers = mutableMapOf<Int, ManeuverViewState>()
    private var activeManeuverIndices = emptyList<Int>()
    private var snapshot = VehicleUiSnapshot()

    @Synchronized
    fun accept(frame: Iap2Frame) {
        snapshot = when (frame.messageId) {
            NOW_PLAYING_UPDATE -> {
                val state = nowPlaying.update(frame)
                snapshot.copy(
                    nowPlaying = NowPlayingViewState(
                        title = state.title,
                        artist = state.artist,
                        album = state.album,
                        appName = state.appName,
                        durationMillis = state.durationMillis,
                        elapsedMillis = state.elapsedMillis,
                        playback = state.status.name.lowercase(),
                        artworkTransferId = state.artworkFileTransferId,
                        receivedAtEpochMillis = System.currentTimeMillis(),
                    ),
                )
            }
            ROUTE_GUIDANCE_UPDATE -> snapshot.copy(navigation = routeGuidance(frame))
            ROUTE_MANEUVER_UPDATE -> snapshot.copy(navigation = maneuverGuidance(frame))
            CALL_STATE_UPDATE -> snapshot.copy(phone = callState(frame))
            else -> return
        }
        publish(snapshot)
    }

    @Synchronized
    fun reset() {
        maneuvers.clear()
        activeManeuverIndices = emptyList()
        snapshot = VehicleUiSnapshot()
        publish(snapshot)
    }

    private fun routeGuidance(frame: Iap2Frame): NavigationViewState {
        val body = Iap2Messages.reader(frame)
        val previous = snapshot.navigation
        val routeState = body.safeU8(ROUTE_STATE) ?: previous.routeState
        val sequence = previous.updateSequence + 1

        if (body.has(MANEUVER_LIST)) {
            activeManeuverIndices = body.safeU16List(MANEUVER_LIST).orEmpty()
        }
        if (routeState == ROUTE_NONE) {
            maneuvers.clear()
            activeManeuverIndices = emptyList()
            return NavigationViewState(updateSequence = sequence)
        }

        return previous.copy(
            active = routeState != ROUTE_ARRIVED,
            maneuverUpdate = false,
            routeState = routeState,
            currentRoad = body.safeString(CURRENT_ROAD) ?: previous.currentRoad,
            destination = body.safeString(DESTINATION) ?: previous.destination,
            estimatedArrival = body.safeU64(ETA) ?: previous.estimatedArrival,
            timeRemainingSeconds = body.safeU64(TIME_REMAINING) ?: previous.timeRemainingSeconds,
            distanceRemainingMeters = body.safeU32(DISTANCE_REMAINING) ?: previous.distanceRemainingMeters,
            distanceRemainingText = body.safeString(DISTANCE_REMAINING_TEXT) ?: previous.distanceRemainingText,
            distanceRemainingUnit = body.safeU8(DISTANCE_REMAINING_UNIT) ?: previous.distanceRemainingUnit,
            distanceToManeuverMeters = body.safeU32(DISTANCE_TO_MANEUVER) ?: previous.distanceToManeuverMeters,
            distanceToManeuverText = body.safeString(DISTANCE_TO_MANEUVER_TEXT) ?: previous.distanceToManeuverText,
            distanceToManeuverUnit = body.safeU8(DISTANCE_TO_MANEUVER_UNIT) ?: previous.distanceToManeuverUnit,
            sourceName = body.safeString(SOURCE_NAME) ?: previous.sourceName,
            maneuver = activeManeuverIndices.firstNotNullOfOrNull(maneuvers::get) ?: previous.maneuver,
            updateSequence = sequence,
        )
    }

    private fun maneuverGuidance(frame: Iap2Frame): NavigationViewState {
        val body = Iap2Messages.reader(frame)
        val index = body.safeU16(MANEUVER_INDEX) ?: return snapshot.navigation.copy(
            maneuverUpdate = true,
            updateSequence = snapshot.navigation.updateSequence + 1,
        )
        val previousManeuver = maneuvers[index] ?: ManeuverViewState(index = index)
        val maneuver = previousManeuver.copy(
            description = body.safeString(MANEUVER_DESCRIPTION) ?: previousManeuver.description,
            roadName = body.safeString(MANEUVER_ROAD) ?: previousManeuver.roadName,
            type = body.safeU8(MANEUVER_TYPE) ?: previousManeuver.type,
            distanceMeters = body.safeU32(MANEUVER_DISTANCE) ?: previousManeuver.distanceMeters,
            distanceText = body.safeString(MANEUVER_DISTANCE_TEXT) ?: previousManeuver.distanceText,
            distanceUnit = body.safeU8(MANEUVER_DISTANCE_UNIT) ?: previousManeuver.distanceUnit,
        )
        maneuvers[index] = maneuver
        val selected = when {
            index in activeManeuverIndices -> maneuver
            snapshot.navigation.maneuver == null && activeManeuverIndices.isEmpty() -> maneuver
            else -> snapshot.navigation.maneuver
        }
        return snapshot.navigation.copy(
            maneuverUpdate = true,
            maneuver = selected,
            updateSequence = snapshot.navigation.updateSequence + 1,
        )
    }

    private fun callState(frame: Iap2Frame): PhoneViewState {
        // The first CallStateUpdate is an empty call list. Different iOS versions encode the
        // list header as either an empty value or a single zero byte; any larger value carries
        // one or more call records. Keeping this deliberately conservative prevents false calls.
        val firstPayload = runCatching {
            com.shilapi.xcertplay.iap2.message.Iap2Messages.reader(frame).first(0)?.payload
        }.getOrNull()
        val active = when (firstPayload?.size) {
            null, 0 -> false
            1 -> firstPayload[0].toInt() != 0
            else -> true
        }
        return PhoneViewState(
            active = active,
            status = if (active) "active" else "idle",
            updateSequence = snapshot.phone.updateSequence + 1,
        )
    }

    private companion object {
        const val NOW_PLAYING_UPDATE = 0x5001
        const val ROUTE_GUIDANCE_UPDATE = 0x5201
        const val ROUTE_MANEUVER_UPDATE = 0x5202
        const val CALL_STATE_UPDATE = 0x4155

        const val ROUTE_STATE = 0x0001
        const val CURRENT_ROAD = 0x0003
        const val DESTINATION = 0x0004
        const val ETA = 0x0005
        const val TIME_REMAINING = 0x0006
        const val DISTANCE_REMAINING = 0x0007
        const val DISTANCE_REMAINING_TEXT = 0x0008
        const val DISTANCE_REMAINING_UNIT = 0x0009
        const val DISTANCE_TO_MANEUVER = 0x000A
        const val DISTANCE_TO_MANEUVER_TEXT = 0x000B
        const val DISTANCE_TO_MANEUVER_UNIT = 0x000C
        const val MANEUVER_LIST = 0x000D
        const val SOURCE_NAME = 0x0013

        const val MANEUVER_INDEX = 0x0001
        const val MANEUVER_DESCRIPTION = 0x0002
        const val MANEUVER_TYPE = 0x0003
        const val MANEUVER_ROAD = 0x0004
        const val MANEUVER_DISTANCE = 0x0005
        const val MANEUVER_DISTANCE_TEXT = 0x0006
        const val MANEUVER_DISTANCE_UNIT = 0x0007

        const val ROUTE_NONE = 0
        const val ROUTE_ARRIVED = 2
    }
}

private fun com.shilapi.xcertplay.iap2.body.Iap2BodyReader.safeU8(id: Int): Int? =
    runCatching { optionalU8(id) }.getOrNull()

private fun com.shilapi.xcertplay.iap2.body.Iap2BodyReader.safeU16(id: Int): Int? =
    runCatching { optionalU16(id) }.getOrNull()

private fun com.shilapi.xcertplay.iap2.body.Iap2BodyReader.safeU32(id: Int): Long? =
    runCatching { optionalU32(id) }.getOrNull()

private fun com.shilapi.xcertplay.iap2.body.Iap2BodyReader.safeU64(id: Int): Long? =
    runCatching { optionalU64(id) }.getOrNull()

private fun com.shilapi.xcertplay.iap2.body.Iap2BodyReader.safeString(id: Int): String? =
    runCatching { optionalString(id)?.takeIf(String::isNotBlank) }.getOrNull()

private fun com.shilapi.xcertplay.iap2.body.Iap2BodyReader.safeU16List(id: Int): List<Int>? =
    runCatching { optionalU16List(id) }.getOrNull()

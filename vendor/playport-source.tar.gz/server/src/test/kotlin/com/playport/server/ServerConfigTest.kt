package com.playport.server

import java.nio.file.Path
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class ServerConfigTest {
    private val defaults = ServerConfig(
        identityDir = Path.of("identity"),
        stateDir = Path.of("state"),
    )

    @Test
    fun roundModeDefaultsToNative480Display() {
        val config = ServerConfig.fromArgs(arrayOf("--round"), defaults)

        assertTrue(config.roundDisplay)
        assertEquals(480, config.displayWidth)
        assertEquals(480, config.displayHeight)
    }

    @Test
    fun diameterSetsBothRoundDisplayAxes() {
        val config = ServerConfig.fromArgs(arrayOf("--round", "--diameter", "1200"), defaults)

        assertEquals(1200, config.displayWidth)
        assertEquals(1200, config.displayHeight)
    }

    @Test
    fun roundModeRejectsDifferentExplicitAxes() {
        assertThrows(IllegalArgumentException::class.java) {
            ServerConfig.fromArgs(
                arrayOf("--round", "--width", "1000", "--height", "800"),
                defaults,
            )
        }
    }

    @Test
    fun higherMainRenderScaleKeepsMapDimensionsAndPersists() {
        val config = ServerConfig.fromArgs(
            arrayOf("--round", "--diameter", "512", "--main-render-scale", "150"), defaults,
        )
        assertEquals(512, config.displayWidth)
        assertEquals(512, config.displayHeight)
        assertEquals(150, config.mainRenderScale)
        val persisted = PersistentConfig.of(config, DisplayState(512, 512, 60, 100, round = true))
        assertEquals(150, persisted.toServerDefaults(Path.of("identity"), Path.of("state")).mainRenderScale)
    }

    @Test
    fun rejectsUnsupportedMainScaleAndOversizedRenderTarget() {
        assertThrows(IllegalArgumentException::class.java) {
            ServerConfig.fromArgs(arrayOf("--main-render-scale", "125"), defaults)
        }
        assertThrows(IllegalArgumentException::class.java) {
            ServerConfig.fromArgs(arrayOf("--diameter", "3840", "--main-render-scale", "200"), defaults)
        }
    }
}

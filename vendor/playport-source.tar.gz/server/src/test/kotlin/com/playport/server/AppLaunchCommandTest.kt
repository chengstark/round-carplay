package com.playport.server

import com.shilapi.xcertplay.airplay.AirPlayInfoPlist
import org.junit.Assert.*
import org.junit.Test

class AppLaunchCommandTest {
    @Test fun appRequestsTargetTheMainScreenWithCarInitiatedShowUi() {
        for ((app, url) in mapOf("youtube-music" to "youtubemusic://", "phone" to "mobilephone://")) {
            val command = appLaunchCommand(app)!!
            assertEquals("showUI", command["type"])
            assertEquals(mapOf("uuid" to AirPlayInfoPlist.MAIN_UUID, "url" to url), command["params"])
        }
    }
    @Test fun arbitraryUrlsCannotBeRequested() {
        assertNull(appLaunchCommand("https://example.com"))
    }
}

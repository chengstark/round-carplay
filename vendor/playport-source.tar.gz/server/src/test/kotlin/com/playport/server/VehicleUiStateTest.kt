package com.playport.server

import com.shilapi.xcertplay.iap2.message.Iap2Messages
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VehicleUiStateTest {
    @Test
    fun publishesNowPlayingAndNavigationUpdates() {
        val published = mutableListOf<VehicleUiSnapshot>()
        val state = VehicleUiState(published::add)

        state.accept(
            Iap2Messages.buildRaw(0x5001) {
                group(0) {
                    string(1, "Midnight Drive")
                    string(12, "PlayPort Radio")
                }
                group(1) {
                    u8(0, 1)
                    u32(1, 25_000)
                    string(7, "Music")
                }
            },
        )
        state.accept(
            Iap2Messages.buildRaw(0x5202) {
                u16(1, 7)
                string(2, "Turn right onto Manor Stone Drive")
                u8(3, 2)
                string(4, "Manor Stone Drive")
            },
        )
        state.accept(
            Iap2Messages.buildRaw(0x5201) {
                u8(1, 1)
                string(3, "Ragan Road")
                string(4, "Downtown")
                u64(6, 1_080)
                u32(7, 8_900)
                string(8, "8.9")
                u8(9, 0)
                u32(10, 350)
                string(11, "350")
                u8(12, 2)
                u16List(13, listOf(7))
            },
        )

        assertEquals("Midnight Drive", published.last().nowPlaying.title)
        assertEquals("PlayPort Radio", published.last().nowPlaying.artist)
        assertEquals("playing", published.last().nowPlaying.playback)
        assertEquals("Music", published.last().nowPlaying.appName)
        assertTrue(published.last().navigation.active)
        assertEquals("Ragan Road", published.last().navigation.currentRoad)
        assertEquals("Downtown", published.last().navigation.destination)
        assertEquals(350L, published.last().navigation.distanceToManeuverMeters)
        assertEquals("Turn right onto Manor Stone Drive", published.last().navigation.maneuver?.description)
        assertEquals(2, published.last().navigation.maneuver?.type)
    }

    @Test
    fun treatsZeroCallListAsIdleAndNonEmptyRecordAsActive() {
        val published = mutableListOf<VehicleUiSnapshot>()
        val state = VehicleUiState(published::add)

        state.accept(Iap2Messages.buildRaw(0x4155) { u8(0, 0) })
        assertFalse(published.last().phone.active)

        state.accept(Iap2Messages.buildRaw(0x4155) { group(0) { u8(0, 1) } })
        assertTrue(published.last().phone.active)
        assertEquals("active", published.last().phone.status)
    }
}

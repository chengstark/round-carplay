package com.playport.server

import org.junit.Assert.assertFalse
import org.junit.Test

class ProcessByteStreamTest {
    @Test fun closeReapsABridgeThatIgnoresGracefulTermination() {
        val process = ProcessBuilder(
            "sh",
            "-c",
            "trap '' TERM; while :; do sleep 1; done",
        ).start()
        val stream = ProcessByteStream(process, "stubborn-test-bridge")
        Thread.sleep(100)

        stream.close()

        assertFalse("bridge process must be reaped before reconnect", process.isAlive)
        stream.close()
    }
}

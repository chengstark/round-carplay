package com.playport.server

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WirelessRecoveryTest {
    @Test fun reconnectsAfterACompletedSessionDropsEvenWhenBluetoothStillRuns() {
        assertFalse(shouldRetryWireless(true, 19_999, true))
        assertTrue(shouldRetryWireless(true, 20_000, true))
    }

    @Test fun givesAFreshHandshakeTimeButBoundsAStalledBootstrap() {
        assertFalse(shouldRetryWireless(true, 20_000, false))
        assertFalse(shouldRetryWireless(true, 89_999, false))
        assertTrue(shouldRetryWireless(true, 90_000, false))
    }

    @Test fun retriesAnExitedBootstrapAfterTheCooldown() {
        assertFalse(shouldRetryWireless(false, 19_999, false))
        assertTrue(shouldRetryWireless(false, 20_000, false))
        assertFalse(shouldRetryWireless(false, -1, true))
    }
}
